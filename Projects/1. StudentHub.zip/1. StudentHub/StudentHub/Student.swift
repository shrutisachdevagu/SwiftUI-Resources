//
//  Student.swift
//  StudentHub
//
//  Created by Shruti Sachdeva on 10/12/25.
//

import Foundation


struct Student {
    var firstName:String = ""
    var lastName:String = ""
    var age:Int = 0
}
