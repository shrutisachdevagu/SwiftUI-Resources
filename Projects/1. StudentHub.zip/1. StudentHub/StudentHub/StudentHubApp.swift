//
//  StudentHubApp.swift
//  StudentHub
//
//  Created by Shruti Sachdeva on 10/12/25.
//

import SwiftUI

@main
struct StudentHubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
