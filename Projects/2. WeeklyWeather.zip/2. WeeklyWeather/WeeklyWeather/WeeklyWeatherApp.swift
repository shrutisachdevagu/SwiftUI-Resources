//
//  WeeklyWeatherApp.swift
//  WeeklyWeather
//
//  Created by Shruti Sachdeva on 09/12/25.
//

import SwiftUI

@main
struct WeeklyWeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
