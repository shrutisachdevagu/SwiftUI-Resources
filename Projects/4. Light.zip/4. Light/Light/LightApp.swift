//
//  LightApp.swift
//  Light
//
//  Created by Shruti Sachdeva on 10/12/25.
//

import SwiftUI

@main
struct LightApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
